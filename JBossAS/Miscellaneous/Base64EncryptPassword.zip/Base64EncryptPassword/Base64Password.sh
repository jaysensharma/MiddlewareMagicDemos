#!/bin/sh

export JAVA_HOME=/user/jdk1.6.0_21   #<= change this path
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=commons-codec.jar:.

java Base64EncryptPassword $1
